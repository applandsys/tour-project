<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\MemberCreateController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/home', function () {
    return Inertia::render('Home', [
        'name' => 'Tarique Mosharraf'
    ]);
});

Route::get('/promo', function () {
    return Inertia::render('Promo', [
        'name' => 'Tarique Mosharraf'
    ]);
});

Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('purchase',[PurchaseController::class,'PurchasePackage'])->name('member.purchase');

    Route::post('purchase-buy-process',[PurchaseController::class,'PackageBuyProcess'])->name('member.package-buy-process');

    Route::post('gt-user',[MemberController::class, 'GTUser'])->name('member.gtuser');

    Route::get('user/deposit',[MemberController::class,'Page'])->name('member.deposit');
    Route::get('user/package/payment/{id}', [MemberController::class, 'Payment'])->name('member.package.payment');
    Route::post('user/package/payment-process', [MemberController::class, 'PaymentProcess'])->name('member.package.paymentProcess');
});


Route::post('/signup-step-one', [MemberCreateController::class,'Signup'])->name('signup.step.one');
Route::post('/signup-otp-verify', [MemberCreateController::class,'Verify'])->name('signup.otp.verify');
Route::post('/modal-login', [MemberCreateController::class,'Login'])->name('signup.step.one');

require __DIR__.'/auth.php';
