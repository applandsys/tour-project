import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import {Head, usePage} from '@inertiajs/react';
import AccountSidebar from "@/Components/User/AccountSidebar.jsx";
import ProfileForm from "@/Components/User/ProfileForm.jsx";
import {FaArrowCircleRight, FaCopy, FaMailBulk, FaPhone} from "react-icons/fa";
import {useState} from "react";

export default function Dashboard() {
    const user = usePage().props.auth.user;

    const [copied, setCopied] = useState(false);
    const referralUrl = `https://globaltrips24.com?ref=${user.unique_id}`;

    const copyToClipboard = async () => {
        try {
            await navigator.clipboard.writeText(referralUrl);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000); // reset after 2s
        } catch (err) {
            console.error("Failed to copy: ", err);
        }
    };

    return (
        <AuthenticatedLayout
            header={
                <div>
                    <h2 className="text-xl font-semibold leading-tight text-white">
                        Home > My Account
                    </h2>
                    <div className="flex justify-between mt-10 text-white">
                        <div className="flex items-center">
                            <div className="w-20 h-20 p-2">
                               <img src="/images/add_photo_icon.png"/>
                            </div>
                            <div className="">
                                <h2 className="text-3xl font-bold">{user.name}</h2>
                                <div className="flex gap-2 item-center mt-2">
                                   <div className="flex  text-sm gap-2"><FaPhone/>+88 01837664478</div>
                                   <div className="flex text-sm gap-2"><FaMailBulk/>applandsys@gmail.com</div>
                                </div>
                            </div>
                        </div>
                        <div className="flex">
                            <div className="flex">
                                <div className="bg-black bg-opacity-80  rounded-md flex items-center justify-center h-8 p-2"><img src="/images/my_wallet_icon.png" className="h-6 w-6 mx-1"/> Wallet BDT. 3000 <FaArrowCircleRight className="text-blue-500 mx-2"/></div>
                            </div>
                        </div>
                    </div>
                </div>
            }
        >
            <Head title="Dashboard" />
            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                        <div className="grid grid-cols-4">
                             <div className="col-span-1 border-r border-gray-300">
                                 <AccountSidebar/>
                             </div>
                            <div className="col-span-3 border-r">
                                <div className="m-4 text-center">
                                    <div className="flex items-center space-x-2">
                                        <span>Referral URL :</span>
                                        <a
                                            href={referralUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-blue-800"
                                        >
                                            {referralUrl}
                                        </a>
                                        <FaCopy
                                            className="mx-2 text-gray-500 cursor-pointer hover:text-gray-700"
                                            onClick={copyToClipboard}
                                        />
                                        {copied && <span className="text-green-600 text-sm">Copied!</span>}
                                    </div>
                                </div>
                                <ProfileForm user={user}/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
